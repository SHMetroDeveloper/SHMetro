//
//  SubModuleViewController.h
//  client_ios_fm_a
//
//  Created by Ausen Inesanet on 21/3/2017.
//  Copyright © 2017 facilityone. All rights reserved.
//

#import "BaseNavigationViewController.h"
#import "PullTableView.h"
#import "QrCodeViewController.h"


@interface SubModuleViewController : BaseViewController

- (instancetype) init;
- (instancetype) initWithFrame:(CGRect)frame;

@end
