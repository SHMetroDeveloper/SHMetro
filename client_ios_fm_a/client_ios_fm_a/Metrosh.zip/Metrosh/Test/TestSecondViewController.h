//
//  TestSecondViewController.h
//  client_ios_fm_a
//
//  Created by flynn.yang on 2017/2/22.
//  Copyright © 2017年 facilityone. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface TestSecondViewController : BaseViewController

- (instancetype) init;
- (instancetype) initWithFrame:(CGRect)frame;

@end
