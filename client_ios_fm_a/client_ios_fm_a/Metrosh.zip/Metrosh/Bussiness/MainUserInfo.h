//
//  Header.h
//  client_ios_fm_a
//
//  Created by Ausen Inesanet on 24/3/2017.
//  Copyright © 2017 facilityone. All rights reserved.
//


#import <Foundation/Foundation.h>

@interface MainUserInfo : NSObject

@property (readwrite, nonatomic, assign) NSInteger userId;
@property (readwrite, nonatomic, assign) NSInteger userType;

@end
